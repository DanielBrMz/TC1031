#include "Nodo.h"

#pragma once
class NodoFila {
public:
    Nodo *nodo;
    NodoFila *siguiente;
};