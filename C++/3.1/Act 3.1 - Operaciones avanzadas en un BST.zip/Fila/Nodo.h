#pragma once
class Nodo {
public:
    int data;
    Nodo *izquierda;
    Nodo *derecha;
};