#pragma once

struct Nodo {
    int dato;
    Nodo* siguiente;
};