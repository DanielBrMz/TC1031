#pragma once

#include <vector>

int busquedaSecuencial(std::vector<int>& numeros, int dato, int& iteraciones);
