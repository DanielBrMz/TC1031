#pragma once

#include <vector>

int busquedaBinaria(std::vector<int>& numeros, int dato, int& iteraciones);
