#pragma once

#include <vector>

int ordenaMerge(std::vector<int>& numeros);
